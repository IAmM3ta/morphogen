import { useRef, useState, type ReactNode } from "react";
import {
  Aperture,
  AudioLines,
  Camera,
  Circle,
  Copy,
  EyeOff,
  FileText,
  House,
  ImagePlus,
  Layers,
  Radio,
  RotateCcw,
  ScanSearch,
  Smartphone,
  SlidersHorizontal,
  Square,
  Undo2,
  Upload,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ParamSlider } from "./param-slider";
import { KeyPad } from "./key-pad";
import { LoopRack } from "./loop-rack";
import { FieldLibrary, ScanPlate, type FieldShot } from "./field-library";
import { PALETTES, PRESETS, WAVEFORMS, waveformById, type ImageMode, type SimParams } from "@/lib/morphogen/presets";
import type { LoopClip } from "@/lib/morphogen/loops";
import { MIDI_MAP, TD_CALLBACKS } from "@/lib/morphogen/td-script";
import { useInstrument, type ImageSlot } from "@/lib/morphogen/store";
import { runtime } from "@/lib/morphogen/runtime";
import { maybeCheckpoint } from "@/lib/morphogen/history";
import { formatKeyMode } from "@/lib/morphogen/theory";
import type { TdStatus } from "@/lib/morphogen/td-client";
import type { MidiDevice } from "@/lib/morphogen/midi-out";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

/** MEMETiC tooltips — Hum / Hands / Field (M-21). */
const TAB_HINTS: Record<string, string> = {
  field: "How the pattern grows. F and k change the species; Default brings it home.",
  image: "Drop a photo onto the field, or use the camera.",
  sense: "Touch plays the pitch under your finger. Drag plants new growth.",
  sound: "The steady tone underneath. Tilt the phone to brighten it.",
  sync: "Stage path — TouchDesigner WebSocket and MIDI. MIDI permission is requested here, not on Enter.",
};

const TABS = [
  { id: "field", label: "Field", icon: SlidersHorizontal },
  { id: "image", label: "Image", icon: ImagePlus },
  { id: "sense", label: "Body", icon: Smartphone },
  { id: "sound", label: "Sound", icon: AudioLines },
  { id: "sync", label: "Sync", icon: Radio },
] as const;

type TabId = (typeof TABS)[number]["id"];

function VibratoControls() {
  const rate = useInstrument((s) => s.vibratoRate);
  const depth = useInstrument((s) => s.vibratoDepth);
  const orbit = useInstrument((s) => s.orbitRate);
  const setRate = useInstrument((s) => s.setVibratoRate);
  const setDepth = useInstrument((s) => s.setVibratoDepth);
  const setOrbit = useInstrument((s) => s.setOrbitRate);
  return (
    <div className="flex flex-col gap-3">
      <ParamSlider
        label="Orbit"
        value={orbit}
        min={0}
        max={8}
        step={0.05}
        format={(n) => (n < 0.03 ? "hold" : `${n.toFixed(2)} Hz`)}
        onChange={setOrbit}
      />
      <ParamSlider
        label="Vibrato rate"
        value={rate}
        min={0.5}
        max={12}
        step={0.1}
        format={(n) => `${n.toFixed(1)} Hz`}
        onChange={setRate}
      />
      <ParamSlider
        label="Vibrato depth"
        value={depth}
        min={0}
        max={1}
        step={0.01}
        format={(n) => (n < 0.005 ? "off" : `${Math.round(n * 80)}¢`)}
        onChange={setDepth}
      />
    </div>
  );
}

function ListenControls({
  onLoadTrack,
  onToggleTrack,
  onToggleMic,
  onShareSystem,
  trackOn,
  trackName,
  micOn,
}: {
  onLoadTrack: (file: File) => void;
  onToggleTrack: () => void;
  onToggleMic: (on: boolean) => void;
  onShareSystem: () => void;
  trackOn: boolean;
  trackName: string;
  micOn: boolean;
}) {
  const listen = useInstrument((s) => s.listen);
  const setListen = useInstrument((s) => s.setListen);
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="flex flex-col gap-3">
      <div>
        <p className="mb-1 text-xs tracking-[0.18em] text-muted uppercase">Ambience</p>
        <p className="text-xs leading-relaxed text-muted">
          Play along with music that is already on. Room hears it out loud.
          A computer can share its audio. The phone cannot open Spotify’s stream.
        </p>
      </div>
      <div className="flex gap-1.5">
        <Button
          variant={micOn ? "secondary" : "ghost"}
          size="sm"
          className="flex-1"
          aria-pressed={micOn}
          onClick={() => onToggleMic(!micOn)}
        >
          Room
        </Button>
        <Button variant="ghost" size="sm" className="flex-1" onClick={() => fileRef.current?.click()}>
          Track
        </Button>
        <Button variant="ghost" size="sm" className="flex-1" onClick={onShareSystem}>
          Share
        </Button>
      </div>
      <ParamSlider
        label="Listen"
        value={listen}
        min={0}
        max={1}
        step={0.01}
        format={(n) => (n < 0.02 ? "off" : `${Math.round(n * 100)}%`)}
        onChange={setListen}
      />
      <input
        ref={fileRef}
        type="file"
        accept="audio/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) onLoadTrack(file);
        }}
      />
      {trackName && (
        <div className="flex gap-2">
          <p className="min-w-0 flex-1 truncate text-xs text-fg">{trackName}</p>
          <Button variant={trackOn ? "default" : "ghost"} size="sm" onClick={onToggleTrack}>
            {trackOn ? "Pause" : "Play"}
          </Button>
        </div>
      )}
      <p className="text-[11px] leading-relaxed text-faint">
        Bass blooms, mids open the field, a hit drops a seed under your fingers. Headphones if you play too.
      </p>
    </div>
  );
}

export function ControlDock({
  tab,
  onTab,
  tdStatus,
  tdError,
  onTdConnect,
  onTdDisconnect,
  midiDevices,
  onMidiSelect,
  onMidiToggle,
  onToggleMic,
  onShareSystem,
  onLoadTrack,
  onToggleTrack,
  trackOn,
  trackName,
  onToggleCamera,
  onHunt,
  onToggleGyro,
  cameraOn,
  onAddImage,
  onPickImage,
  onUsePalette,
  onLock,
  onPop,
  onClearLocks,
  lockCount,
  onReset,
  onDefaults,
  atDefaults,
  onRecord,
  recording,
  onUndo,
  canUndo,
  compassLive,
  shots,
  onCapture,
  onDownloadShot,
  loops,
  layerRecording,
  onLayerRecord,
  onLayerStop,
  onLoopPlay,
  onLoopLoop,
  onLoopRemove,
}: {
  tab: TabId;
  onTab: (t: TabId) => void;
  tdStatus: TdStatus;
  tdError: string;
  onTdConnect: () => void;
  onTdDisconnect: () => void;
  midiDevices: MidiDevice[];
  onMidiSelect: (id: string | null) => void;
  onMidiToggle: (on: boolean) => void;
  onToggleMic: (on: boolean) => void;
  onShareSystem: () => void;
  onLoadTrack: (file: File) => void;
  onToggleTrack: () => void;
  trackOn: boolean;
  trackName: string;
  onToggleCamera: (on: boolean) => void;
  onHunt: () => void;
  onToggleGyro: (on: boolean) => void;
  cameraOn: boolean;
  onAddImage: (files: FileList | null) => void;
  onPickImage: (id: string) => void;
  onUsePalette: () => void;
  onLock: () => void;
  onPop: () => void;
  onClearLocks: () => void;
  lockCount: number;
  onReset: () => void;
  onDefaults: () => void;
  atDefaults: boolean;
  onRecord: () => void;
  recording: boolean;
  onUndo: () => void;
  canUndo: boolean;
  compassLive: boolean;
  shots: FieldShot[];
  onCapture: () => void;
  onDownloadShot: (id: string) => void;
  loops: LoopClip[];
  layerRecording: boolean;
  onLayerRecord: () => void;
  onLayerStop: () => void;
  onLoopPlay: (id: string, playing: boolean) => void;
  onLoopLoop: (id: string, looping: boolean) => void;
  onLoopRemove: (id: string) => void;
}) {
  const {
    params,
    setParam,
    setImageMode,
    applyPreset,
    presetId,
    waveform,
    setWaveform,
    images,
    activeImageId,
    gyroOn,
    micOn,
    audioOn,
    volume,
    muted,
    tdUrl,
    tdGrid,
    midiOn,
    midiId,
    panelOpen,
    patch,
    keyId,
    modeId,
    pitchMinHz,
    pitchMaxHz,
  } = useInstrument();
  const fileRef = useRef<HTMLInputElement>(null);
  const [face, setFace] = useState<"field" | "sound">("sound");
  const [sheetOpen, setSheetOpen] = useState(false);

  const hideChrome = () => {
    setSheetOpen(false);
    patch({ uiHidden: true, panelOpen: false });
  };
  const openFace = (next: "field" | "sound") => {
    if (face === next && sheetOpen) setSheetOpen(false);
    else {
      setFace(next);
      setSheetOpen(true);
    }
  };

  if (!panelOpen) {
    const fmt4 = (n: number) => n.toFixed(4);
    const soundLabel = `${waveformById(waveform).name} · ${formatKeyMode(keyId, modeId)} · ${Math.round(pitchMinHz)}–${Math.round(pitchMaxHz)} Hz`;
    return (
      <div
        data-ui
        className={cn(
          "pointer-events-auto relative z-50 flex w-full flex-col-reverse overflow-hidden rounded-xl bg-bg/35 px-3 pt-3 pb-3 text-fg shadow-[var(--shadow-border)] sm:absolute sm:right-3 sm:bottom-3 sm:w-80 sm:flex-col",
          sheetOpen && "max-h-[min(72dvh,32rem)]",
        )}
      >
        <div className="flex shrink-0 flex-col gap-2">
          <div className="flex items-center gap-1.5">
            <Button
              variant={lockCount > 0 ? "secondary" : "outline"}
              size="default"
              className="min-h-11 flex-1"
              onClick={onLock}
              aria-label="Freeze: stop growth"
              title="Freeze: stop growth. Release: let it grow again."
            >
              <Layers />
              {lockCount > 0 ? `Freeze ${lockCount}` : "Freeze"}
            </Button>
            <Button
              variant="ghost"
              size="default"
              className="min-h-11 flex-1"
              onClick={onPop}
              disabled={lockCount === 0}
              aria-label="Release: let it grow again"
              title="Freeze: stop growth. Release: let it grow again."
            >
              Release
            </Button>
            <Button
              variant="faint"
              size="icon"
              onClick={hideChrome}
              aria-label="Hide controls"
              title="Hide controls — tap the eye to bring them back"
            >
              <EyeOff />
            </Button>
          </div>
          {lockCount > 1 && (
            <button type="button" className="self-end text-xs text-faint hover:text-muted" onClick={onClearLocks}>
              Release all
            </button>
          )}
          <div className="flex gap-1">
            <Button
              variant={sheetOpen && face === "field" ? "secondary" : "ghost"}
              size="sm"
              className="flex-1"
              onClick={() => openFace("field")}
              aria-pressed={sheetOpen && face === "field"}
              aria-label="Field"
              title="How the pattern grows. F and k change the species; Default brings it home."
            >
              Field
            </Button>
            <Button
              variant={sheetOpen && face === "sound" ? "secondary" : "ghost"}
              size="sm"
              className="flex-1"
              onClick={() => openFace("sound")}
              aria-pressed={sheetOpen && face === "sound"}
              aria-label="Sound"
              title="The steady tone underneath. Tilt the phone to brighten it."
            >
              Sound
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => patch({ panelOpen: true })}
              aria-label="More controls"
              title="More controls"
            >
              More
            </Button>
            <Button asChild variant="ghost" size="sm">
              <a href="/guide/Morphos-Instrument-Guide.pdf" download="Morphos-Instrument-Guide.pdf">
                <FileText />
                Guide
              </a>
            </Button>
          </div>
        </div>

        {sheetOpen && (
          <div className="mb-3 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto sm:mt-3 sm:mb-0">
            <div className="sticky top-0 z-10 flex items-center justify-between gap-2 py-1">
              <p className="text-xs tracking-[0.18em] text-muted uppercase">
                {face === "sound" ? "Sound" : "Field"}
              </p>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" onClick={() => setSheetOpen(false)} aria-label="Hide menu">
                  Hide menu
                </Button>
                <Button
                  variant="faint"
                  size="sm"
                  onClick={hideChrome}
                  aria-label="Hide controls"
                  title="Hide every control. Tap the eye to bring them back."
                >
                  <EyeOff />
                  Hide
                </Button>
              </div>
            </div>
            {face === "field" ? (
          <>
            <p className="text-xs leading-relaxed text-muted">
              Freeze: stop growth. Release: let it grow again. Field — How the
              pattern grows. F and k change the species; Default brings it home.
            </p>
            <button
              type="button"
              onClick={() => openFace("sound")}
              className="rounded-sm px-2.5 py-2 text-left text-xs shadow-[var(--shadow-border)] hover:bg-fg/6"
            >
              <span className="block tracking-[0.18em] text-muted uppercase">Sound</span>
              <span className="mt-0.5 block text-fg">{soundLabel}</span>
            </button>
            <div>
              <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Colour</p>
              <PaletteSwatches value={params.paletteId} onPick={(id) => setParam("paletteId", id)} />
            </div>
            <ParamSlider
              label="Feed"
              symbol="F"
              value={params.feed}
              min={0.01}
              max={0.09}
              step={0.0005}
              format={fmt4}
              onChange={(n) => setParam("feed", n)}
            />
            <ParamSlider
              label="Kill"
              symbol="k"
              value={params.kill}
              min={0.03}
              max={0.08}
              step={0.0005}
              format={fmt4}
              onChange={(n) => setParam("kill", n)}
            />
            <div className="flex gap-2">
              <Button
                variant={atDefaults ? "secondary" : "ghost"}
                size="sm"
                className="flex-1"
                onClick={onDefaults}
                aria-pressed={atDefaults}
              >
                <House /> Default
              </Button>
              <Button variant="ghost" size="sm" className="flex-1" onClick={onReset}>
                <RotateCcw /> Reset
              </Button>
              <Button variant="ghost" size="sm" onClick={onCapture} aria-label="Capture field" title="Capture field">
                <Camera />
              </Button>
            </div>
          </>
        ) : (
          <>
            <p className="text-xs leading-relaxed text-muted">
              The scale is a polygon. The center holds a note; the outer
              rings step through the scale. Freeze stops growth, so the
              shape holds while you drag it. Set Orbit to 0 for a steady
              drone.
            </p>
            <div>
              <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Waveform</p>
              <div className="grid grid-cols-3 gap-1.5">
                {WAVEFORMS.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setWaveform(w.id)}
                    className={cn(
                      "rounded-sm px-2 py-2 text-center shadow-[var(--shadow-border)] transition-colors duration-150",
                      waveform === w.id ? "bg-fg/90 text-bg" : "bg-bg/25 text-fg hover:bg-fg/10",
                    )}
                    aria-pressed={waveform === w.id}
                  >
                    <span className="block text-xs font-medium">{w.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <VibratoControls />
            <ListenControls
              onLoadTrack={onLoadTrack}
              onToggleTrack={onToggleTrack}
              onToggleMic={onToggleMic}
              onShareSystem={onShareSystem}
              trackOn={trackOn}
              trackName={trackName}
              micOn={micOn}
            />
            <KeyPad compassLive={compassLive} compact />
            <div className="flex gap-2">
              <Button
                variant={atDefaults ? "secondary" : "ghost"}
                size="sm"
                className="flex-1"
                onClick={onDefaults}
                aria-pressed={atDefaults}
              >
                <House /> Default
              </Button>
              <Button variant="ghost" size="sm" className="flex-1" onClick={onReset}>
                <RotateCcw /> Reset
              </Button>
            </div>
          </>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <aside
      data-ui
      className="pointer-events-auto relative z-50 flex h-[min(72dvh,36rem)] w-full flex-col overflow-hidden rounded-xl bg-bg/45 text-fg shadow-[var(--shadow-border)] sm:absolute sm:right-3 sm:top-hud-t sm:bottom-3 sm:h-auto sm:w-80"
    >
      <header className="flex items-center justify-between px-4 pt-3 pb-2">
        <p className="text-xs tracking-[0.28em] text-muted uppercase">Console</p>
        <div className="flex items-center gap-1">
          <Button
            variant="faint"
            size="icon-sm"
            onClick={() => patch({ uiHidden: true, panelOpen: false })}
            aria-label="Hide controls"
            title="Hide controls"
          >
            <EyeOff />
          </Button>
          <Button variant="faint" size="icon-sm" onClick={() => patch({ panelOpen: false })} aria-label="Close" title="Close">
            <X />
          </Button>
        </div>
      </header>
      <nav className="flex gap-0.5 px-3 pb-2">
        {TABS.map((t) => {
          const Icon = t.icon;
          const on = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => onTab(t.id)}
              className={cn(
                "flex h-11 flex-1 flex-col items-center justify-center gap-0.5 rounded-sm text-muted transition-colors duration-150",
                on ? "bg-bg-subtle text-fg" : "hover:text-fg",
              )}
              aria-pressed={on}
              aria-label={t.label}
              title={TAB_HINTS[t.id] ?? t.label}
            >
              <Icon className="size-4" aria-hidden />
              <span className="text-[9px] tracking-[0.1em] uppercase">{t.label}</span>
            </button>
          );
        })}
      </nav>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-5">
        {tab === "field" && (
          <FieldTab
            params={params}
            presetId={presetId}
            lockCount={lockCount}
            recording={recording}
            canUndo={canUndo}
            setParam={setParam}
            applyPreset={applyPreset}
            onLock={onLock}
            onPop={onPop}
            onClearLocks={onClearLocks}
            onUndo={onUndo}
            onReset={onReset}
            onDefaults={onDefaults}
            atDefaults={atDefaults}
            onRecord={onRecord}
            shots={shots}
            onCapture={onCapture}
            onDownloadShot={onDownloadShot}
          />
        )}

        {tab === "image" && (
          <ImageTab
            images={images}
            activeImageId={activeImageId}
            imageMode={params.imageMode}
            imageMix={params.imageMix}
            fileRef={fileRef}
            cameraOn={cameraOn}
            onAddImage={onAddImage}
            onPickImage={onPickImage}
            onUsePalette={onUsePalette}
            onToggleCamera={onToggleCamera}
            onHunt={onHunt}
            setImageMode={setImageMode}
            setMix={(n) => setParam("imageMix", n)}
          />
        )}

        {tab === "sense" && (
          <div className="flex flex-col gap-5">
            <ToggleRow
              label="Tilt & motion"
              hint="Hum — The steady tone underneath. Tilt the phone to brighten it."
              checked={gyroOn}
              onCheckedChange={onToggleGyro}
            />
            <ToggleRow
              label="Microphone"
              hint="Room and voice drive the field when Listen is up. Bass feeds, mids kill, highs sparkle."
              checked={micOn}
              onCheckedChange={onToggleMic}
            />
            <p className="text-xs leading-relaxed text-muted">
              Hands — Touch plays the pitch under your finger. Drag plants new
              growth. Hum — The steady tone underneath. Tilt the phone to
              brighten it.
            </p>
            <div className="rounded-md bg-bg-subtle p-3">
              <p className="text-xs text-muted">Open on another phone</p>
              <p className="mt-2 break-all font-mono text-[11px] text-fg">
                {typeof window !== "undefined" ? window.location.origin : ""}
              </p>
              <Button
                variant="secondary"
                size="sm"
                className="mt-3 w-full"
                onClick={() => {
                  const link = window.location.origin;
                  void navigator.clipboard?.writeText(link);
                  toast("Link copied");
                }}
              >
                <Copy /> Copy link
              </Button>
            </div>
          </div>
        )}

        {tab === "sound" && (
          <div className="flex flex-col gap-5">
            <ToggleRow
              label="Default settings"
              hint="Overtone chant, D Dorian, factory mix. Clears recorded layers. Home, if you get lost in the noise."
              checked={atDefaults}
              onCheckedChange={(on) => {
                if (on) onDefaults();
              }}
            />
            <ToggleRow
              label="Voice of the field"
              hint="Hum — The steady tone underneath. Tilt the phone to brighten it."
              checked={audioOn}
              onCheckedChange={(on) => patch({ audioOn: on })}
            />
            <ParamSlider
              label="Level"
              value={volume}
              min={0}
              max={1}
              step={0.01}
              format={(n) => `${Math.round(n * 100)}%`}
              onChange={(n) => patch({ volume: n })}
            />
            <ToggleRow
              label="Mute"
              hint="Silence without stopping the field."
              checked={muted}
              onCheckedChange={(on) => patch({ muted: on })}
            />
            <p className="text-xs text-muted">
              Hands — Touch plays the pitch under your finger. Drag plants new
              growth. Hum — The steady tone underneath. Tilt the phone to
              brighten it.
            </p>
            <div>
              <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Waveform</p>
              <p className="mb-2 text-xs leading-relaxed text-muted">
                Sine is The Hum. Spectrum reads the field as harmonic
                partials — the chemistry becomes the timbre.
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {WAVEFORMS.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setWaveform(w.id)}
                    className={cn(
                      "rounded-sm px-2.5 py-2 text-left shadow-[var(--shadow-border)] transition-colors duration-150",
                      waveform === w.id ? "bg-fg text-bg" : "bg-transparent text-fg hover:bg-fg/6",
                    )}
                  >
                    <span className="block text-xs font-medium">{w.name}</span>
                    <span className={cn("block text-[10px]", waveform === w.id ? "text-bg/70" : "text-faint")}>
                      {w.blurb}
                    </span>
                  </button>
                ))}
              </div>
            </div>
            <KeyPad compassLive={compassLive} />
            <VibratoControls />
            <ListenControls
              onLoadTrack={onLoadTrack}
              onToggleTrack={onToggleTrack}
              onToggleMic={onToggleMic}
              onShareSystem={onShareSystem}
              trackOn={trackOn}
              trackName={trackName}
              micOn={micOn}
            />
            <LoopRack
              clips={loops}
              recording={layerRecording}
              onRecord={onLayerRecord}
              onStop={onLayerStop}
              onTogglePlay={onLoopPlay}
              onToggleLoop={onLoopLoop}
              onRemove={onLoopRemove}
            />
          </div>
        )}

        {tab === "sync" && (
          <SyncTab
            tdUrl={tdUrl}
            tdGrid={tdGrid}
            tdStatus={tdStatus}
            tdError={tdError}
            midiOn={midiOn}
            midiId={midiId}
            midiDevices={midiDevices}
            onTdConnect={onTdConnect}
            onTdDisconnect={onTdDisconnect}
            onMidiSelect={onMidiSelect}
            onMidiToggle={onMidiToggle}
          />
        )}
      </div>
    </aside>
  );
}

function PaletteSwatches({ value, onPick }: { value: string; onPick: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {PALETTES.map((p) => (
        <button
          key={p.id}
          type="button"
          title={`${p.name} — tones The Hum`}
          onClick={() => onPick(p.id)}
          className={cn(
            "size-7 overflow-hidden rounded-full shadow-[var(--shadow-border)]",
            value === p.id && "ring-2 ring-fg",
          )}
          aria-label={p.name}
        >
          <span
            className="block h-full w-full"
            style={{
              background: `linear-gradient(135deg, rgb(${p.stops[1]!.map((c) => Math.round(c * 255)).join(",")}), rgb(${p.stops[3]!.map((c) => Math.round(c * 255)).join(",")}))`,
            }}
          />
        </button>
      ))}
    </div>
  );
}

function FieldTab({
  params,
  presetId,
  lockCount,
  recording,
  canUndo,
  setParam,
  applyPreset,
  onLock,
  onPop,
  onClearLocks,
  onUndo,
  onReset,
  onDefaults,
  atDefaults,
  onRecord,
  shots,
  onCapture,
  onDownloadShot,
}: {
  params: SimParams;
  presetId: string;
  lockCount: number;
  recording: boolean;
  canUndo: boolean;
  setParam: <K extends keyof SimParams>(key: K, value: SimParams[K]) => void;
  applyPreset: (id: string) => void;
  onLock: () => void;
  onPop: () => void;
  onClearLocks: () => void;
  onUndo: () => void;
  onReset: () => void;
  onDefaults: () => void;
  atDefaults: boolean;
  onRecord: () => void;
  shots: FieldShot[];
  onCapture: () => void;
  onDownloadShot: (id: string) => void;
}) {
  const [term, setTerm] = useState<PdeTerm>(null);
  const fmt4 = (n: number) => n.toFixed(4);
  const fmt3 = (n: number) => n.toFixed(3);
  const fmt2 = (n: number) => n.toFixed(2);

  return (
    <div className="flex flex-col gap-5">
      <section>
        <ToggleRow
          label="Default settings"
          hint="Coral, warm sine, D Dorian. Clears loops, layers, and locks. Home, if you get lost in the noise."
          checked={atDefaults}
          onCheckedChange={(on) => {
            if (on) onDefaults();
          }}
        />
      </section>

      <section>
        <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Equations</p>
        <p className="mb-2 text-xs leading-relaxed text-muted">
          Pearson Gray–Scott. Touch a coefficient to bind the slider.
        </p>
        <GrayScottPde active={term} onPick={setTerm} />
      </section>

      <section className="flex flex-col gap-3">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Parameters</p>
        <ParamSlider
          label="Feed"
          symbol="F"
          value={params.feed}
          min={0.01}
          max={0.09}
          step={0.0005}
          format={fmt4}
          onChange={(n) => setParam("feed", n)}
          onActive={(on) => {
            if (on) setTerm("F");
          }}
        />
        <ParamSlider
          label="Kill"
          symbol="k"
          value={params.kill}
          min={0.03}
          max={0.08}
          step={0.0005}
          format={fmt4}
          onChange={(n) => setParam("kill", n)}
          onActive={(on) => {
            if (on) setTerm("k");
          }}
        />
        <ParamSlider
          label="Diffusion U"
          symbol="Dᵤ"
          value={params.du}
          min={0.08}
          max={0.36}
          step={0.005}
          format={fmt3}
          onChange={(n) => setParam("du", n)}
          onActive={(on) => {
            if (on) setTerm("Du");
          }}
        />
        <ParamSlider
          label="Diffusion V"
          symbol="Dᵥ"
          value={params.dv}
          min={0.04}
          max={0.2}
          step={0.005}
          format={fmt3}
          onChange={(n) => setParam("dv", n)}
          onActive={(on) => {
            if (on) setTerm("Dv");
          }}
        />
      </section>

      <section>
        <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Species</p>
        <p className="mb-2 text-xs leading-relaxed text-muted">
          Named (F, k, Dᵤ, Dᵥ) packs. Morphs in place — the field is not reset.
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => applyPreset(p.id)}
              className={cn(
                "rounded-sm px-2.5 py-2 text-left shadow-[var(--shadow-border)] transition-colors duration-150",
                presetId === p.id ? "bg-fg text-bg" : "bg-transparent text-fg hover:bg-fg/6",
              )}
            >
              <span className="block text-xs font-medium">{p.name}</span>
              <span className={cn("block text-xs", presetId === p.id ? "text-bg/70" : "text-faint")}>
                F {p.feed.toFixed(3)} · k {p.kill.toFixed(3)}
              </span>
            </button>
          ))}
        </div>
      </section>

      <FieldLibrary shots={shots} onCapture={onCapture} onDownloadShot={onDownloadShot} />

      <section className="flex flex-col gap-3">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Brush</p>
        <p className="text-xs leading-relaxed text-muted">
          Disk · species <em>v</em> = 1, <em>u</em> = ½. Paints initial conditions, not a mark on the glass.
        </p>
        <ParamSlider
          label="Radius"
          symbol="R"
          value={params.brushSize}
          min={0.01}
          max={0.07}
          step={0.002}
          format={fmt3}
          onChange={(n) => setParam("brushSize", n)}
        />
        <ParamSlider
          label="Value"
          symbol="B"
          value={params.brushStrength}
          min={0.15}
          max={1}
          step={0.01}
          format={fmt2}
          onChange={(n) => setParam("brushStrength", n)}
        />
      </section>

      <section className="flex flex-col gap-3">
        <p className="text-xs tracking-[0.18em] text-muted uppercase">Time</p>
        <ParamSlider
          label="Steps / frame"
          symbol="N"
          value={params.steps}
          min={4}
          max={40}
          step={1}
          format={(n) => String(Math.round(n))}
          onChange={(n) => setParam("steps", Math.round(n))}
        />
        <ParamSlider
          label="Timestep"
          symbol="Δt"
          value={params.speed}
          min={0.35}
          max={1.2}
          step={0.05}
          format={fmt2}
          onChange={(n) => setParam("speed", n)}
        />
      </section>

      <section>
        <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Views</p>
        <p className="mb-2 text-xs leading-relaxed text-muted">
          Colour map of <em>v</em>, with hillshade from ∇v. Each circle is also
          a tone-colour — it retunes The Hum (brightness, third/fifth, air).
        </p>
        <div className="mb-3">
          <PaletteSwatches value={params.paletteId} onPick={(id) => setParam("paletteId", id)} />
        </div>
        <ParamSlider
          label="Lighting"
          symbol="L"
          value={params.glow}
          min={0.2}
          max={2}
          step={0.05}
          format={fmt2}
          onChange={(n) => setParam("glow", n)}
        />
        <Button
          variant="secondary"
          size="sm"
          className="mt-3 w-full"
          onClick={() => {
            maybeCheckpoint();
            runtime.seedNonce += 1;
          }}
        >
          <RotateCcw /> Reseed
        </Button>
      </section>

      <section>
        <p className="mb-2 text-xs tracking-[0.18em] text-muted uppercase">Loop</p>
        <p className="mb-3 text-xs leading-relaxed text-muted">
          Freeze: stop growth. Release: let it grow again.
        </p>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            className="flex-1"
            onClick={onLock}
            aria-label="Freeze: stop growth"
            title="Freeze: stop growth. Release: let it grow again."
          >
            Freeze
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onPop}
            disabled={lockCount === 0}
            aria-label="Release: let it grow again"
            title="Freeze: stop growth. Release: let it grow again."
          >
            Release
          </Button>
        </div>
        <div className="mt-2 flex gap-2">
          <Button variant="ghost" size="sm" className="flex-1" onClick={onUndo} disabled={!canUndo}>
            <Undo2 /> Undo
          </Button>
          <Button variant="ghost" size="sm" className="flex-1" onClick={onReset}>
            <RotateCcw /> Reset
          </Button>
        </div>
        <div className="mt-2 flex gap-2">
          <Button
            variant={atDefaults ? "secondary" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={onDefaults}
            aria-pressed={atDefaults}
          >
            <House /> Defaults
          </Button>
          <Button
            variant={recording ? "secondary" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={onRecord}
          >
            {recording ? <Square /> : <Circle />}
            {recording ? "Stop" : "Record"}
          </Button>
        </div>
        {lockCount > 1 && (
          <button type="button" className="mt-2 text-xs text-faint hover:text-muted" onClick={onClearLocks}>
            Clear all loops
          </button>
        )}
      </section>
    </div>
  );
}

type PdeTerm = "F" | "k" | "Du" | "Dv" | null;

function GrayScottPde({ active, onPick }: { active: PdeTerm; onPick: (t: PdeTerm) => void }) {
  const t = (id: Exclude<PdeTerm, null>, label: ReactNode) => (
    <button
      type="button"
      className="pde-term"
      data-on={active === id}
      data-pde-term={id}
      aria-pressed={active === id}
      onClick={() => onPick(active === id ? null : id)}
    >
      {label}
    </button>
  );

  return (
    <div className="pde rounded-md bg-bg-subtle px-3 py-2.5">
      <p>
        ∂<em>u</em>/∂t = {t("Du", <>D<sub>u</sub></>)} ∇²<em>u</em> − <em>uv</em>² + {t("F", "F")}(1−<em>u</em>)
      </p>
      <p>
        ∂<em>v</em>/∂t = {t("Dv", <>D<sub>v</sub></>)} ∇²<em>v</em> + <em>uv</em>² − ({t("F", "F")}+{t("k", "k")})<em>v</em>
      </p>
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  checked,
  onCheckedChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div>
        <p className="text-sm text-fg">{label}</p>
        <p className="mt-0.5 text-xs leading-relaxed text-muted">{hint}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

function ImageTab({
  images,
  activeImageId,
  imageMode,
  imageMix,
  fileRef,
  cameraOn,
  onAddImage,
  onPickImage,
  onUsePalette,
  onToggleCamera,
  onHunt,
  setImageMode,
  setMix,
}: {
  images: ImageSlot[];
  activeImageId: string | null;
  imageMode: ImageMode;
  imageMix: number;
  fileRef: React.RefObject<HTMLInputElement | null>;
  cameraOn: boolean;
  onAddImage: (files: FileList | null) => void;
  onPickImage: (id: string) => void;
  onUsePalette: () => void;
  onToggleCamera: (on: boolean) => void;
  onHunt: () => void;
  setImageMode: (m: ImageMode) => void;
  setMix: (n: number) => void;
}) {
  return (
    <div className="flex flex-col gap-5">
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => onAddImage(e.target.files)}
      />
      <div className="flex gap-2">
        <Button variant="secondary" size="sm" className="flex-1" onClick={() => fileRef.current?.click()}>
          <Upload /> Add image
        </Button>
        <Button
          variant={cameraOn ? "default" : "secondary"}
          size="sm"
          onClick={() => onToggleCamera(!cameraOn)}
        >
          <Camera />
        </Button>
      </div>
      <ScanPlate />
      <Button variant="secondary" size="sm" className="w-full" onClick={onHunt}>
        <ScanSearch /> Find sticker
      </Button>
      <p className="text-xs leading-relaxed text-muted">
        Point the camera at a print. The field locks to that origin and lives
        on the paper — a cache in the city.
      </p>
      {images.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {images.map((img) => (
            <button
              key={img.id}
              type="button"
              onClick={() => onPickImage(img.id)}
              className={cn(
                "size-14 shrink-0 overflow-hidden rounded-sm",
                activeImageId === img.id ? "ring-2 ring-fg" : "shadow-[var(--shadow-border)]",
              )}
            >
              <img src={img.url} alt={img.name} className="size-full object-cover" />
            </button>
          ))}
        </div>
      )}
      <div>
        <p className="mb-2 text-xs text-muted">How the photograph feeds the field</p>
        <div className="grid grid-cols-2 gap-1.5">
          {(
            [
              ["inoculate", "Inoculate"],
              ["develop", "Develop"],
              ["resist", "Resist"],
              ["palette", "Palette only"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setImageMode(id)}
              className={cn(
                "rounded-sm px-2 py-2 text-xs shadow-[var(--shadow-border)]",
                imageMode === id ? "bg-fg text-bg" : "text-fg hover:bg-fg/6",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      <ParamSlider
        label="Image mix"
        value={imageMix}
        min={0}
        max={1}
        step={0.01}
        format={(n) => `${Math.round(n * 100)}%`}
        onChange={setMix}
      />
      <Button variant="outline" size="sm" onClick={onUsePalette}>
        <Aperture /> Sample colors from image
      </Button>
      <p className="text-xs leading-relaxed text-muted">
        Drop a photo onto the field, or use the camera. Inoculate seeds growth in
        bright regions. Develop lets the picture emerge through the reaction.
        Resist turns dark areas into walls.
      </p>
    </div>
  );
}

function SyncTab({
  tdUrl,
  tdGrid,
  tdStatus,
  tdError,
  midiOn,
  midiId,
  midiDevices,
  onTdConnect,
  onTdDisconnect,
  onMidiSelect,
  onMidiToggle,
}: {
  tdUrl: string;
  tdGrid: boolean;
  tdStatus: TdStatus;
  tdError: string;
  midiOn: boolean;
  midiId: string | null;
  midiDevices: MidiDevice[];
  onTdConnect: () => void;
  onTdDisconnect: () => void;
  onMidiSelect: (id: string | null) => void;
  onMidiToggle: (on: boolean) => void;
}) {
  const patch = useInstrument((s) => s.patch);
  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-sm text-fg">TouchDesigner WebSocket</p>
        <p className="mt-1 text-xs leading-relaxed text-muted">
          Two pipes. Pixels: NDI / Spout / Window COMP of this canvas — that
          is the chemical. Knobs: this socket at 20 Hz, mapped onto IIHQ
          Tutorial 087 (Feedback → Blur → Sharpen → Level → Transform).
          Name those ops <span className="font-mono text-fg">blur, sharpen, level1, xform, feedback1</span> and
          the callbacks ride them. Reset in MORPHOS pulses the Feedback TOP.
        </p>
        <input
          value={tdUrl}
          onChange={(e) => patch({ tdUrl: e.target.value })}
          spellCheck={false}
          className="mt-3 h-11 w-full rounded-md bg-bg px-3 font-mono text-xs text-fg shadow-[var(--shadow-border)] outline-none focus:ring-2 focus:ring-ring/50"
          placeholder="ws://127.0.0.1:9980"
        />
        <div className="mt-2 flex gap-2">
          {tdStatus === "connected" ? (
            <Button variant="secondary" size="sm" className="flex-1" onClick={onTdDisconnect}>
              Disconnect
            </Button>
          ) : (
            <Button size="sm" className="flex-1" onClick={onTdConnect}>
              Connect
            </Button>
          )}
        </div>
        <p className="mt-2 text-xs text-muted">
          {tdStatus === "connected"
            ? "Streaming"
            : tdStatus === "connecting"
              ? "Connecting…"
              : tdStatus === "error"
                ? tdError
                : "Idle"}
        </p>
        <ToggleRow
          label="Include 16×16 grid"
          hint="Rebuild as a TOP from Table DAT morphogen_grid."
          checked={tdGrid}
          onCheckedChange={(v) => patch({ tdGrid: v })}
        />
        <div className="mt-3 flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => {
              void navigator.clipboard?.writeText(TD_CALLBACKS);
              toast("TouchDesigner callbacks copied");
            }}
          >
            <Copy /> Copy TD callbacks
          </Button>
          <a
            href="/td/morphogen_ws_callbacks.py"
            download
            className="inline-flex h-9 items-center rounded-sm px-3 text-xs text-fg shadow-[var(--shadow-border)]"
          >
            Download
          </a>
        </div>
      </div>
      <div>
        <p className="text-sm text-fg">MIDI to TouchDesigner</p>
        <p className="mt-1 text-xs leading-relaxed text-muted">
          Same-machine path with no network. Enable a virtual port (IAC / loopMIDI)
          and a MIDI In CHOP. CCs 20–35: chemistry, field, bands, 087 blur/opacity.
        </p>
        <ToggleRow
          label="Send MIDI CC"
          hint={MIDI_MAP.map((m) => `${m.cc} ${m.name}`).join(" · ")}
          checked={midiOn}
          onCheckedChange={(v) => onMidiToggle(v)}
        />
        {midiDevices.length > 0 && (
          <select
            className="mt-2 h-11 w-full rounded-md bg-bg px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none"
            value={midiId ?? ""}
            onChange={(e) => onMidiSelect(e.target.value || null)}
          >
            <option value="">Choose port</option>
            {midiDevices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        )}
      </div>
      <div>
        <p className="text-sm text-fg">Projector picture</p>
        <p className="mt-1 text-xs leading-relaxed text-muted">
          Hide the chrome (H) and fullscreen (F). Capture this window with NDI
          Screen Capture or a Window COMP. The living field is the video; the
          socket and MIDI are the data.
        </p>
      </div>
    </div>
  );
}
