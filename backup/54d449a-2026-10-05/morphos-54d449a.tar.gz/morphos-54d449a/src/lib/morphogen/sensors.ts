import { runtime } from "./runtime";
import { MAX_BRUSHES, type Brush } from "./presets";

type DOE = typeof DeviceOrientationEvent & {
  requestPermission?: () => Promise<"granted" | "denied">;
};

type DME = typeof DeviceMotionEvent & {
  requestPermission?: () => Promise<"granted" | "denied">;
};

type OrientEvent = DeviceOrientationEvent & { webkitCompassHeading?: number };

export type SensorSample = {
  alpha: number;
  beta: number;
  gamma: number;
  heading: number;
  ax: number;
  ay: number;
  az: number;
  ux: number;
  uy: number;
  uz: number;
  gx: number;
  gy: number;
  gz: number;
};

export const sensorSample: SensorSample = {
  alpha: 0,
  beta: 0,
  gamma: 0,
  heading: 0,
  ax: 0,
  ay: 0,
  az: 0,
  ux: 0,
  uy: 0,
  uz: 0,
  gx: 0,
  gy: 0,
  gz: 0,
};

export async function requestSensorPermission(): Promise<boolean> {
  try {
    const DOE = DeviceOrientationEvent as DOE;
    if (typeof DOE.requestPermission === "function") {
      const res = await DOE.requestPermission();
      if (res !== "granted") return false;
    }
    const DME = DeviceMotionEvent as DME;
    if (typeof DME.requestPermission === "function") {
      const res = await DME.requestPermission();
      if (res !== "granted") return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function attachSensors(): () => void {
  let restG = 0;
  let restB = 0;
  let restA = 0;
  let samples = 0;
  let calibrated = false;
  let spin = 0;
  let lastMag = 9.81;

  const applyOrient = (e: OrientEvent) => {
    const gamma = e.gamma ?? 0;
    const beta = e.beta ?? 0;
    const alpha = e.alpha ?? 0;
    sensorSample.alpha = alpha;
    sensorSample.beta = beta;
    sensorSample.gamma = gamma;
    if (typeof e.webkitCompassHeading === "number") {
      sensorSample.heading = e.webkitCompassHeading;
      runtime.sense.compass = true;
    } else if (e.absolute) {
      sensorSample.heading = ((alpha % 360) + 360) % 360;
      runtime.sense.compass = true;
    } else {
      sensorSample.heading = ((alpha % 360) + 360) % 360;
    }

    // Absolute pose is the other antenna — how you hold the phone is the sound.
    runtime.sense.roll = Math.max(-1, Math.min(1, gamma / 42));
    runtime.sense.pitch = Math.max(-1, Math.min(1, (beta - 40) / 52));
    runtime.sense.heading = sensorSample.heading;

    if (!calibrated) {
      restG += gamma;
      restB += beta;
      restA += alpha;
      samples += 1;
      if (samples >= 8) {
        restG /= samples;
        restB /= samples;
        restA /= samples;
        calibrated = true;
      }
      runtime.flowX = 0;
      runtime.flowY = 0;
      runtime.sense.yaw = 0;
      return;
    }
    let dx = gamma - restG;
    let dy = beta - restB;
    let dz = alpha - restA;
    if (dz > 180) dz -= 360;
    if (dz < -180) dz += 360;
    const soften = (v: number) => (Math.abs(v) < 1.1 ? v * 0.4 : v);
    dx = soften(dx);
    dy = soften(dy);
    runtime.sense.yaw = Math.max(-1, Math.min(1, dz / 70));
    runtime.flowX = Math.max(-0.35, Math.min(0.35, (dx / 32) * 0.22));
    runtime.flowY = Math.max(-0.35, Math.min(0.35, (dy / 36) * 0.22));
  };

  const onOrient = (e: DeviceOrientationEvent) => applyOrient(e as OrientEvent);
  const onOrientAbs = (e: Event) => applyOrient(e as OrientEvent);

  const onMotion = (e: DeviceMotionEvent) => {
    const g = e.accelerationIncludingGravity;
    let mag = lastMag;
    if (g) {
      sensorSample.ax = g.x ?? 0;
      sensorSample.ay = g.y ?? 0;
      sensorSample.az = g.z ?? 0;
      mag = Math.hypot(g.x ?? 0, g.y ?? 0, g.z ?? 0);
      runtime.sense.gforce = Math.max(0, Math.min(1.8, mag / 9.81 - 0.92));
    }
    const a = e.acceleration;
    if (a) {
      sensorSample.ux = a.x ?? 0;
      sensorSample.uy = a.y ?? 0;
      sensorSample.uz = a.z ?? 0;
    }
    const r = e.rotationRate;
    let fromRate = 0;
    if (r) {
      sensorSample.gx = r.alpha ?? 0;
      sensorSample.gy = r.beta ?? 0;
      sensorSample.gz = r.gamma ?? 0;
      fromRate = Math.min(1, Math.hypot(r.alpha ?? 0, r.beta ?? 0, r.gamma ?? 0) / 140);
    }
    const jerk = Math.min(1, Math.abs(mag - lastMag) / 3.2);
    lastMag = mag;
    spin = spin * 0.76 + Math.max(fromRate, jerk) * 0.24;
    runtime.sense.spin = spin;
  };

  window.addEventListener("deviceorientation", onOrient);
  window.addEventListener("deviceorientationabsolute", onOrientAbs);
  window.addEventListener("devicemotion", onMotion);
  return () => {
    window.removeEventListener("deviceorientation", onOrient);
    window.removeEventListener("deviceorientationabsolute", onOrientAbs);
    window.removeEventListener("devicemotion", onMotion);
    runtime.flowX = 0;
    runtime.flowY = 0;
    runtime.sense.roll = 0;
    runtime.sense.pitch = 0;
    runtime.sense.yaw = 0;
    runtime.sense.spin = 0;
  };
}

type Finger = {
  id: number;
  x: number;
  y: number;
  px: number;
  py: number;
  sx: number;
  sy: number;
  /** Birth time — used to collapse pointer/touch duplicates of one finger. */
  t: number;
  /** True after an explicit drag — plants growth (M-06 / MEMETiC Hands). */
  planting: boolean;
  pressure: number;
  radius: number;
};

export type ContactKind = "down" | "move" | "up";

export type ContactEvent = {
  type: ContactKind;
  id: number;
  x: number;
  y: number;
  pressure: number;
  radius: number;
};

/**
 * Pointer/touch → play hands always; field brushes only after an explicit drag.
 * Touch plays; drag plants (M-06). Freeze is a labeled button on the glass (Freeze: stop growth. Release: let it grow again.) — no tap-and-hold gesture.
 */
export function localPointerBrushes(
  canvas: HTMLElement,
  getSize: () => { size: number; strength: number },
  onChange?: (brushes: Brush[]) => void,
  _onLock?: (x: number, y: number) => void,
  _onCharge?: (charge: number, x: number, y: number) => void,
  onContact?: (evt: ContactEvent) => void,
): () => void {
  const fingers = new Map<number, Finger>();
  const alias = new Map<number, number>();
  const TAP_MOVE = 22;
  const NEAR_PX = 18;
  /** Touch.identifier offset so mouse pointerId (often 1) never collides. */
  const TOUCH_ID = 1000;
  let windowBound = false;

  const feel = (pressure: number, width: number, height: number) => {
    const p = Number.isFinite(pressure) ? pressure : 0;
    const r = Math.max(width, height);
    return {
      pressure: p > 0.02 && p < 0.999 ? p : p >= 0.999 ? 1 : 0.55,
      radius: Math.max(0.15, Math.min(1, r > 1 ? r / 48 : 0.45)),
    };
  };

  const sync = () => {
    const hands: Brush[] = [];
    const paint: Brush[] = [];
    let maxP = 0;
    for (const f of fingers.values()) {
      const { size, strength } = getSize();
      maxP = Math.max(maxP, f.pressure);
      const brush: Brush = {
        id: f.id,
        x: f.x,
        y: f.y,
        px: f.px,
        py: f.py,
        size: size * (0.78 + f.radius * 0.5),
        strength: strength * (0.7 + f.pressure * 0.45),
        pressure: f.pressure,
        radius: f.radius,
      };
      if (hands.length < MAX_BRUSHES) hands.push(brush);
      if (f.planting && paint.length < MAX_BRUSHES) paint.push(brush);
    }
    runtime.sense.pressure = maxP;
    runtime.hands = hands;
    if (onChange) onChange(paint);
    else runtime.brushes = paint;
  };

  const fromClient = (clientX: number, clientY: number) => {
    const r = canvas.getBoundingClientRect();
    const w = Math.max(1, r.width);
    const h = Math.max(1, r.height);
    return {
      x: (clientX - r.left) / w,
      y: (clientY - r.top) / h,
      px: clientX - r.left,
      py: clientY - r.top,
      w,
      h,
    };
  };

  const canon = (id: number) => alias.get(id) ?? id;

  const nearFinger = (clientX: number, clientY: number, maxPx = NEAR_PX): Finger | null => {
    const { px, py, w, h } = fromClient(clientX, clientY);
    const now = performance.now();
    let best: Finger | null = null;
    let bestD = maxPx;
    for (const f of fingers.values()) {
      // Only collapse pointer/touch duplicates of the same physical finger
      // (born in the same instant, same place). Never merge two real voices.
      if (now - f.t > 90) continue;
      const d = Math.hypot(px - f.x * w, py - f.y * h);
      if (d < bestD) {
        best = f;
        bestD = d;
      }
    }
    return best;
  };

  const dropAliases = (id: number) => {
    const cid = canon(id);
    for (const [k, v] of alias) {
      if (k === id || k === cid || v === id || v === cid) alias.delete(k);
    }
  };

  const emit = (type: ContactKind, f: Finger) => {
    onContact?.({ type, id: f.id, x: f.x, y: f.y, pressure: f.pressure, radius: f.radius });
  };

  const begin = (id: number, clientX: number, clientY: number, pressure: number, width: number, height: number) => {
    if (fingers.has(canon(id))) {
      move(canon(id), clientX, clientY, pressure, width, height);
      return;
    }
    const twin = nearFinger(clientX, clientY);
    if (twin) {
      alias.set(id, twin.id);
      move(twin.id, clientX, clientY, pressure, width, height);
      return;
    }

    const { x, y, px, py } = fromClient(clientX, clientY);
    const fFeel = feel(pressure, width, height);
    const f: Finger = {
      id,
      x,
      y,
      px: x,
      py: y,
      sx: px,
      sy: py,
      t: performance.now(),
      planting: false,
      pressure: fFeel.pressure,
      radius: fFeel.radius,
    };
    fingers.set(id, f);
    runtime.antenna = { x, y, on: false, pressure: 0 };
    sync();
    emit("down", f);
  };

  const move = (
    id: number,
    clientX: number,
    clientY: number,
    pressure: number,
    width: number,
    height: number,
  ) => {
    const f = fingers.get(id);
    if (!f) return;
    const { x, y, px, py } = fromClient(clientX, clientY);
    f.px = f.x;
    f.py = f.y;
    f.x = x;
    f.y = y;
    const felt = feel(pressure, width, height);
    f.pressure = felt.pressure;
    f.radius = felt.radius;
    const dx = f.x - f.px;
    const dy = f.y - f.py;
    runtime.pointerMotion = Math.min(1.8, runtime.pointerMotion + Math.hypot(dx, dy) * 8);
    if (!f.planting && Math.hypot(px - f.sx, py - f.sy) > TAP_MOVE) {
      f.planting = true;
    }
    sync();
    emit("move", f);
  };

  const end = (id: number, clientX: number, clientY: number) => {
    const cid = canon(id);
    const f = fingers.get(cid);
    if (!f) return;
    const { x, y } = fromClient(clientX, clientY);
    f.x = x;
    f.y = y;
    emit("up", f);
    fingers.delete(cid);
    dropAliases(cid);
    sync();
  };

  const isUi = (target: EventTarget | null) =>
    Boolean((target as HTMLElement | null)?.closest?.("[data-ui]"));

  const drive = (
    id: number,
    clientX: number,
    clientY: number,
    pressure: number,
    width: number,
    height: number,
  ) => {
    const cid = canon(id);
    if (fingers.has(cid)) {
      move(cid, clientX, clientY, pressure, width, height);
      return;
    }
    // Same physical finger as a pointer/touch duplicate — not a second voice.
    const near = nearFinger(clientX, clientY);
    if (near) {
      alias.set(id, near.id);
      move(near.id, clientX, clientY, pressure, width, height);
      return;
    }
    begin(id, clientX, clientY, pressure, width, height);
  };

  const down = (e: PointerEvent) => {
    if (isUi(e.target)) return;
    // TouchEvent owns actual fingers — iOS Pointer Events drop extras.
    if (e.pointerType === "touch") return;
    e.preventDefault();
    if (e.pointerType !== "touch") {
      try {
        canvas.setPointerCapture(e.pointerId);
      } catch {
        /* capture is optional */
      }
    }
    begin(e.pointerId, e.clientX, e.clientY, e.pressure, e.width, e.height);
    bindWindow();
  };

  const onPointerMove = (e: PointerEvent) => {
    if (e.pointerType === "touch") return;
    const cid = canon(e.pointerId);
    const known = fingers.has(cid) || fingers.has(e.pointerId);
    if (known) {
      if (e.cancelable && !isUi(e.target)) e.preventDefault();
      const extras = typeof e.getCoalescedEvents === "function" ? e.getCoalescedEvents() : null;
      if (extras && extras.length > 1) {
        for (const c of extras) drive(e.pointerId, c.clientX, c.clientY, c.pressure, c.width, c.height);
      } else {
        drive(e.pointerId, e.clientX, e.clientY, e.pressure, e.width, e.height);
      }
      return;
    }
    if (isUi(e.target)) {
      runtime.antenna.on = false;
      return;
    }
    if (e.pointerType === "mouse" || e.pointerType === "pen") {
      const { x, y } = fromClient(e.clientX, e.clientY);
      runtime.antenna = {
        x,
        y,
        on: true,
        pressure: e.buttons ? Math.max(0.35, e.pressure) : 0.28,
      };
    }
  };

  const up = (e: PointerEvent) => {
    if (e.pointerType === "touch") return;
    const cid = canon(e.pointerId);
    if (!fingers.has(cid) && !fingers.has(e.pointerId)) {
      unbindWindow();
      return;
    }
    end(e.pointerId, e.clientX, e.clientY);
    try {
      canvas.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
    unbindWindow();
  };

  const onPointerLeave = (e: PointerEvent) => {
    if (e.pointerType === "mouse" || e.pointerType === "pen") {
      if (!fingers.has(canon(e.pointerId))) runtime.antenna.on = false;
    }
  };

  const onTouchStart = (e: TouchEvent) => {
    if (isUi(e.target)) return;
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches.item(i);
      if (!t) continue;
      begin(TOUCH_ID + t.identifier, t.clientX, t.clientY, t.force, t.radiusX * 2, t.radiusY * 2);
    }
    bindWindow();
  };

  const onTouchMove = (e: TouchEvent) => {
    if (fingers.size === 0) return;
    if (isUi(e.target) && e.target !== canvas) return;
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches.item(i);
      if (!t) continue;
      drive(TOUCH_ID + t.identifier, t.clientX, t.clientY, t.force, t.radiusX * 2, t.radiusY * 2);
    }
  };

  const onTouchEnd = (e: TouchEvent) => {
    if (fingers.size === 0) return;
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches.item(i);
      if (!t) continue;
      end(TOUCH_ID + t.identifier, t.clientX, t.clientY);
    }
    unbindWindow();
  };

  const clearAll = () => {
    for (const f of fingers.values()) emit("up", f);
    fingers.clear();
    alias.clear();
    runtime.antenna.on = false;
    sync();
    unbindWindow();
  };

  const pointerOpts: AddEventListenerOptions = { passive: false, capture: true };
  const touchOpts: AddEventListenerOptions = { passive: false, capture: true };
  // Must be non-passive: onPointerMove may call preventDefault while tracking.
  const winMoveOpts: AddEventListenerOptions = { passive: false };
  const winUpOpts: AddEventListenerOptions = { capture: true };

  const bindWindow = () => {
    if (windowBound) return;
    windowBound = true;
    window.addEventListener("pointermove", onPointerMove, winMoveOpts);
    window.addEventListener("pointerup", up, winUpOpts);
    window.addEventListener("pointercancel", up, winUpOpts);
    window.addEventListener("touchmove", onTouchMove, touchOpts);
    window.addEventListener("touchend", onTouchEnd, touchOpts);
    window.addEventListener("touchcancel", onTouchEnd, touchOpts);
  };

  const unbindWindow = () => {
    if (!windowBound || fingers.size > 0) return;
    windowBound = false;
    window.removeEventListener("pointermove", onPointerMove, winMoveOpts);
    window.removeEventListener("pointerup", up, winUpOpts);
    window.removeEventListener("pointercancel", up, winUpOpts);
    window.removeEventListener("touchmove", onTouchMove, touchOpts);
    window.removeEventListener("touchend", onTouchEnd, touchOpts);
    window.removeEventListener("touchcancel", onTouchEnd, touchOpts);
  };

  const onBlur = () => clearAll();
  const onVis = () => {
    if (document.visibilityState !== "visible") clearAll();
  };

  canvas.addEventListener("pointerdown", down, pointerOpts);
  canvas.addEventListener("pointermove", onPointerMove, pointerOpts);
  canvas.addEventListener("pointerup", up, pointerOpts);
  canvas.addEventListener("pointercancel", up, pointerOpts);
  canvas.addEventListener("pointerleave", onPointerLeave);
  canvas.addEventListener("touchstart", onTouchStart, touchOpts);
  canvas.addEventListener("touchmove", onTouchMove, touchOpts);
  canvas.addEventListener("touchend", onTouchEnd, touchOpts);
  canvas.addEventListener("touchcancel", onTouchEnd, touchOpts);
  window.addEventListener("blur", onBlur);
  document.addEventListener("visibilitychange", onVis);
  canvas.style.touchAction = "none";
  canvas.style.userSelect = "none";

  return () => {
    fingers.clear();
    alias.clear();
    unbindWindow();
    canvas.removeEventListener("pointerdown", down, pointerOpts);
    canvas.removeEventListener("pointermove", onPointerMove, pointerOpts);
    canvas.removeEventListener("pointerup", up, pointerOpts);
    canvas.removeEventListener("pointercancel", up, pointerOpts);
    canvas.removeEventListener("pointerleave", onPointerLeave);
    canvas.removeEventListener("touchstart", onTouchStart, touchOpts);
    canvas.removeEventListener("touchmove", onTouchMove, touchOpts);
    canvas.removeEventListener("touchend", onTouchEnd, touchOpts);
    canvas.removeEventListener("touchcancel", onTouchEnd, touchOpts);
    window.removeEventListener("blur", onBlur);
    document.removeEventListener("visibilitychange", onVis);
    runtime.antenna.on = false;
    runtime.hands = [];
    sync();
  };
}
